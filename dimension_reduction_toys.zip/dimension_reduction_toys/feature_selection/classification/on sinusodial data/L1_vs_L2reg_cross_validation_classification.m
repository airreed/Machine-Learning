function L1_vs_L2reg_cross_validation_classification()
% Here we illustrate 3-fold cross validation for regression

% Variables
deg = 10;
lams = logspace(-3,0,30);

% load data
[a,b] = load_data();

% split points into 3 equal sized sets and plot
c = split_data(b);

% do 3-fold cross-validation
cross_validate(a,b,c,lams,deg);  

function c = split_data(b)
    % split data into 3 equal sized sets
    K = length(b);
    order = randperm(K);
    c = ones(K,1);
    K = round((1/3)*K);
    c(order(K+1:2*K)) =2;
    c(order(2*K+1:end)) = 3;
end
        
function cross_validate(A_orig,b,c,lams,poly_deg)  
    %%% performs 3-fold cross validation

    % solve for weights and collect test errors
   
    % generate features
    A = [];
    for k = 1:poly_deg
        A = [A, A_orig(:,1).^(poly_deg + 1 - k)];
    end
    A = [ones(size(A,1),1), A, A_orig(:,2)];
    test_errors_L1 = [];
    test_errors_L2 = [];
    for i = 1:length(lams)        
        test_resids_L1 = [];
        test_resids_L2 = [];
        for j = 1:3
            A_1 = A(find(c ~= j),:);
            b_1 = b(find(c ~= j));
            A_2 = A(find(c==j),:);
            b_2 = b(find(c==j));
            x = fast_grad_descent_L1_soft_SVM(A_1',b_1,lams(i));
            resid = evaluate(A_2,b_2,x);
            test_resids_L1 = [test_resids_L1 resid];
            x = fast_grad_descent_L2_soft_SVM(A_1',b_1,lams(i));
            resid = evaluate(A_2,b_2,x);           
            test_resids_L2 = [test_resids_L2 resid];
        end
        test_errors_L1 = [test_errors_L1; test_resids_L1];
        test_errors_L2 = [test_errors_L2; test_resids_L2];
    end
    %%% plot L1 data %%%
    test_ave = mean(test_errors_L1');
    [val,j] = min(test_ave);
    xmin1 = fast_grad_descent_L1_soft_SVM(A',b,lams(j));
    
    % output model
    hold on
    subplot(1,2,1)
    plot_poly(xmin1,poly_deg,'m')   
   
    % output model
    %%% plot L2 results %%%
    test_ave = mean(test_errors_L2');
    [val,j] = min(test_ave);
    xmin2 = fast_grad_descent_L2_soft_SVM(A',b,lams(j));
    
    hold on
    subplot(1,2,1)
    plot_poly(xmin2,poly_deg,'k')   
    axis([0 1 -1.5 1.5])
    box on
    xlabel('a_1','Fontsize',14,'FontName','cmmi9')
    ylabel('a_2  ','Fontsize',14,'FontName','cmmi9')
    set(get(gca,'YLabel'),'Rotation',0)
%     set(gca,'YTickLabel',[])
%     set(gca,'YTick',[])
    box off
    set(gcf,'color','w');
    set(gca,'FontSize',12); 
    
    % output model
    subplot(1,2,2)
    bar(0:length(xmin1)-1,[xmin1, xmin2]);
    mycolor=[1 0 1;0 0 0];
    colormap(mycolor)
    xlabel('x-index','Fontsize',14,'FontName','cmr10')
    set(gcf,'color','w');
    box off
end
    
function plot_poly(x,poly_deg,color)
    % Generate poly seperator
    range = [0:0.01:1];
    x_new = -x/x(end);
    t = 0;
    for i = 1:poly_deg
        t = t + x_new(i+1)*range.^(poly_deg + 1 - i);
    end
    t = t + x_new(1);

    % plot separator
    plot(range,t,color,'linewidth',1.25);
    axis([0 1 -1.5 1.5])
end

function x = fast_grad_descent_L1_soft_SVM(D,b,lam)
    % Initializations 
    x = randn(size(D,1),1);    % initial point
    H = diag(b)*D';
    L = 2*norm(H)^2;           % Lipschitz constant of perceptron
    alpha = 1/L;               % step length
    l = ones(size(D,2),1);
    iter = 1;
    max_its = 3000;
    stopper = 1;
    y = x;
    while  stopper > 10^-6 && iter < max_its
        % form gradient and take accelerated step
        x0 = x;
        grad = - 2*H'*max(l-H*y,0);
        x = y - alpha*grad;
        x(2:end) = max(abs(x(2:end)) - 2*lam*alpha,0).*sign(x(2:end));
        y = x + iter/(iter+3)*(x - x0);
        
        % update stopper/iteration count
        stopper = norm(x - x0)/norm(x0);
        iter = iter + 1;
    end
end


function x = fast_grad_descent_L2_soft_SVM(D,b,lam)
    % Initializations 
    x = randn(size(D,1),1);        % initial point
    H = diag(b)*D';
    L = 2*norm(H)^2;           % Lipschitz constant of perceptron
    alpha = 1/(L + 2*lam);       % step length 

    l = ones(size(D,2),1);
    iter = 1;
    max_its = 3000;
    grad = 1;
    y = x;
    while  norm(grad) > 10^-6 && iter < max_its        
        % form gradient and take accelerated step
        x0 = x;
        grad = - 2*H'*max(l-H*y,0) + 2*lam*[0;y(2:end)];
        x = y - alpha*grad;
        y = x + iter/(iter+3)*(x - x0);
        
        % update iteration count
        iter = iter + 1;
    end
end

function [A,b] = load_data()
    
    data = load('new_sin_class_approx_data.mat');
    data = data.data;
    A = data(:,1:end - 1);
    b = data(:,end);

    % Generate points and plot
    subplot(1,2,1)
    ind = find(b == 1);
    plot(A(ind,1),A(ind,2),'o','MarkerEdgeColor','b','MarkerFaceColor','b','MarkerSize',7)
    hold on
    ind = find(b == -1);
    plot(A(ind,1),A(ind,2),'o','MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',7)
end

function score = evaluate(A,b,x)
% compute score of trained model on test data

    score = 0;  % initialize
    s = A*x;
    ind = find(s > 0);
    s(ind) = 1;
    ind = find(s <= 0);
    s(ind) = -1;
    t = s.*b;
    ind = find(t < 0);
    t(ind) = 0;
    score = 1 - sum(t)/numel(t);

end

end



