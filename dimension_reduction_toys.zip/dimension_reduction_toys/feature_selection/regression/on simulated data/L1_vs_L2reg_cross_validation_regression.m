function L1_vs_L2reg_cross_validation_regression()
% Here we illustrate 3-fold cross validation for regression

% Variables
deg = 10;
lams = logspace(-5,0,30);

% load data
[a,b] = load_data();

% split points into 3 equal sized sets and plot
c = split_data(b);

% do 3-fold cross-validation
cross_validate(a,b,c,lams,deg);  

function c = split_data(b)
    % split data into 3 equal sized sets
    K = length(b);
    order = randperm(K);
    c = ones(K,1);
    K = round((1/3)*K);
    c(order(K+1:2*K)) =2;
    c(order(2*K+1:end)) = 3;
end
        
function cross_validate(a,b,c,lams,deg)  
    %%% performs 3-fold cross validation

    % solve for weights and collect test errors
   
    % generate features
    A = [];
    for j = 0:deg
        A = [A  a.^j];
    end
    U = zeros(size(A,2));
    U(2:end,2:end) = eye(size(A,2)-1);
    test_errors_L1 = [];
    test_errors_L2 = [];
    for i = 1:length(lams)        
        test_resids_L1 = [];
        test_resids_L2 = [];
        for j = 1:3
            A_1 = A(find(c ~= j),:);
            b_1 = b(find(c ~= j));
            A_2 = A(find(c==j),:);
            b_2 = b(find(c==j));
            x = fast_grad_descent_L1_reg_LS(A_1',b_1,lams(i));
            resid = norm(A_2*x - b_2)/numel(b_2);
            test_resids_L1 = [test_resids_L1 resid];
            x = linsolve(A_1'*A_1 + lams(i)*U,A_1'*b_1);
            resid = norm(A_2*x - b_2)/numel(b_2);            
            test_resids_L2 = [test_resids_L2 resid];
        end
        test_errors_L1 = [test_errors_L1; test_resids_L1];
        test_errors_L2 = [test_errors_L2; test_resids_L2];
    end
    %%% plot L1 data %%%
    test_ave = mean(test_errors_L1');
    [val,j] = min(test_ave);
    xmin1 = fast_grad_descent_L1_reg_LS(A',b,lams(j));
    
    % output model
    plot_poly(xmin1,'m',deg)   
   
    % output model
    %%% plot L2 results %%%
    test_ave = mean(test_errors_L2');
    [val,j] = min(test_ave);
    xmin2 = linsolve(A'*A + lams(j)*U,A'*b);
   
    subplot(1,2,1)
    hold on
    plot_poly(xmin2,'k',deg)   
    axis([0 1 -2 2]) 
    box on
    xlabel('a','Fontsize',14,'FontName','cmmi9')
    ylabel('b','Fontsize',14,'FontName','cmmi9')
    set(get(gca,'YLabel'),'Rotation',0)
%     set(gca,'YTickLabel',[])
%     set(gca,'YTick',[])
    box off
    set(gcf,'color','w');
    set(gca,'FontSize',12); 
    
    % output model
    subplot(1,2,2)
    bar(0:length(xmin1)-1,[xmin1, xmin2]);
    mycolor=[1 0 1;0 0 0];
    colormap(mycolor)
    xlabel('x-index','Fontsize',14,'FontName','cmr10')
    set(gcf,'color','w');
    box off
end
    
function plot_poly(x,color,deg)
    s = [0:0.001:1];
    t = 0;
    for k = 1:deg+1;
        t = t + x(k)*s.^(k-1);
    end
    plot(s,t,color,'LineWidth',1.25)
end

function x = fast_grad_descent_L1_reg_LS(A,b,lam)
    % Initializations 
    x = randn(size(A,1),1);    % initial point
    L = norm(A)^2;           % Lipschitz constant of perceptron
    alpha = 1/L;               % step length
    iter = 1;
    max_its = 2000;
    stopper = 1;
    y = x;
    A2 = A*A';
    b2 = A*b;
    while  stopper > 10^-5 && iter < max_its
        % form gradient and take accelerated step
        x0 = x;
        grad = A2*y - b2;
        x = y - alpha*grad;
        x(2:end) = max(abs(x(2:end)) - 2*lam*alpha,0).*sign(x(2:end));
        y = x + iter/(iter+3)*(x - x0);
        
        % update stopper/iteration count
        stopper = norm(x - x0)/norm(x0);
        iter = iter + 1;
    end
end

function [a,b] = load_data()
        
    % load points and plot
    data = load('discrete_sin_data.mat');
    data = data.c;
    a = data(:,1);
    b = data(:,2);

    % plot
    subplot(1,2,1)
    plot(a,b,'o','MarkerEdgeColor','k','MarkerFaceColor','k')
    hold on
    xlabel('a','Fontsize',14,'FontName','cmr10')
    ylabel('b','Fontsize',14,'FontName','cmr10')

end

end



