function log_poly_discrete_cross_validation_feat_select()
% Here is illustrated feature selection with 3-fold cross validation
% using logistic regression and polyonimal features
clear all

% poly degs to look over
poly_degs = 1:15;
num_feats = 4;

% load data etc.,
[A,b] = load_data();

% split points into 3 equal sized sets and plot
c = split_data(A,b);

% do 3-fold cross-validation
cross_validate(A,b,c,poly_degs,num_feats);  

function c = split_data(a,b)
    % split data into 3 equal sized sets
    K = length(b);
    order = randperm(K);
    c = ones(K,1);
    K = round((1/3)*K);
    c(order(K+1:2*K)) =2;
    c(order(2*K+1:end)) = 3;
end
        
function cross_validate(A_orig,b,c,poly_degs,desired_num)  
    %%% performs 3-fold cross validation

    % solve for weights and collect test errors
    highest_poly_deg = poly_degs(end);
    feats = []; 
    while length(feats) < desired_num
        test_errors = [];
        for i = 1:length(poly_degs)
            % generate features
            poly_deg = poly_degs(i);  
            temp = [feats poly_deg];
            A = [];
            for k = 1:length(temp)
                A = [A, A_orig(:,1).^temp(k)];
            end
            A = [ones(size(A,1),1), A, A_orig(:,2)]; % we always include a_2 feat in these experiments

            test_resids = [];
            for j = 1:3
                A_1 = A(find(c ~= j),:);
                b_1 = b(find(c ~= j));
                A_2 = A(find(c==j),:);
                b_2 = b(find(c==j));

                % run logistic regression
                x = fast_grad_descent_logistic(A_1,b_1);

                % compute test error
                resid = evaluate(A_2,b_2,x);
                test_resids = [test_resids resid]; 
            end
            test_errors = [test_errors; test_resids];
        end
        % choose next feature based on minimum ave test error
        test_ave = mean(test_errors');
        [val,j] = min(test_ave);
        
        % add best new feature to feature set, remove from check list
        feats = [feats, poly_degs(j)];
        poly_degs(j) = []; 
    end

    % plot best separator for all data
    A = [];
    for k = 1:length(feats)
        A = [A, A_orig(:,1).^feats(k)];
    end
    A = [ ones(size(A,1),1) ,A, A_orig(:,2)];
    xmin= fast_grad_descent_logistic(A,b);
    
    hold on
    plot_poly(xmin,feats,'k')
    box on
    set(gcf,'color','w');
    
    % plot chosen feature weightings
    figure(2)
    z = zeros(highest_poly_deg + 2,1);
    z(1:length(xmin) - 1) = xmin(1:end - 1);
    z(end) = xmin(end);
    bar(0:length(z)-1,z);
    xlabel('x-index','Fontsize',14,'FontName','cmr10')
    set(gcf,'color','w');
    box off
end
    
function plot_poly(x,feats,color)
    % Generate poly seperator
    range = [0:0.01:10];
    x_new = -x/x(end);
    t = 0;
    for i = 1:length(feats)
        t = t + x_new(i+1)*range.^feats(i);
    end
    t = t + x_new(1);

    % plot separator
    plot(range,t,color,'linewidth',1.25);
    axis([0 1 -1.5 1.5])
end

function [A,b] = load_data()
           
    data = load('new_sin_class_approx_data.mat');
    data = data.data;
    A = data(:,1:end - 1);
    b = data(:,end);

    % Generate points and plot
    ind = find(b == 1);
    plot(A(ind,1),A(ind,2),'o','MarkerEdgeColor','b','MarkerFaceColor','b','MarkerSize',7)
    hold on
    ind = find(b == -1);
    plot(A(ind,1),A(ind,2),'o','MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',7)
end

function x = fast_grad_descent_logistic(A,b)
    % Initializations 
    L = norm(A)^2;
    alpha = 4/L;
    x = randn(size(A,2),1);
    y = x;
    grad = 1;
    iter = 1;
    max_its = 2000;
    A = diag(b)*A;
    % main loop
    while norm(grad) > 10^-5 && iter <= max_its 
        % form gradient and take accelerated step
        x0 = x;
        grad = - (A'*(sigmoid(-A*y)));
        x = y - alpha*grad;
        y = x + iter/(iter+3)*(x - x0);
        iter = iter + 1;
    end

    % sigmoid function
    function y = sigmoid(z)
    y = 1./(1+exp(-z));
    end

end

function score = evaluate(A,b,x)
    % compute score of trained model on test data

    score = 0;  % initialize
    s = A*x;
    ind = find(s > 0);
    s(ind) = 1;
    ind = find(s <= 0);
    s(ind) = -1;
    t = s.*b;
    ind = find(t < 0);
    t(ind) = 0;
    score = 1 - sum(t)/numel(t);

end

end





