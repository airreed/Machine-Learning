function log_discrete_feature_selection()
% Here is illustrated feature selection with 3-fold cross validation
% using logistic regression and polyonimal features
% clear all

% poly degs to look over
num_feats = 1;

% load data etc.,
[A,b] = load_data();

% split points into 3 equal sized sets and plot
c = split_data(A,b);

% do 3-fold cross-validation
cross_validate(A,b,c,num_feats);  

function c = split_data(a,b)
    % split data into 3 equal sized sets
    K = length(b);
    order = randperm(K);
    c = ones(K,1);
    K = round((1/3)*K);
    c(order(K+1:2*K)) =2;
    c(order(2*K+1:end)) = 3;
end
        
function cross_validate(A_orig,b,c,desired_num)  
    %%% performs 3-fold cross validation

    % solve for weights and collect test errors
    feats = []; 
    while length(feats) < desired_num
        test_errors = [];
        for i = 1:2
            % generate features
            A = [];
            if i == 1
                A = [ones(size(A,1),1), A_orig(:,1)];
            else
                A = [ones(size(A,1),1), A_orig(:,2)];
            end

            test_resids = [];
            for j = 1:3
                A_1 = A(find(c ~= j),:);
                b_1 = b(find(c ~= j));
                A_2 = A(find(c==j),:);
                b_2 = b(find(c==j));

                % run logistic regression
                x = fast_grad_descent_logistic(A_1,b_1);

                % compute test error
                resid = evaluate(A_2,b_2,x);
                test_resids = [test_resids resid]; 
            end
            test_errors = [test_errors; test_resids];
        end
        % choose next feature based on minimum ave test error
        test_ave = mean(test_errors');
        [val,j] = min(test_ave);
        
        % add best new feature to feature set, remove from check list
        feats = [feats, j];
    end

    % plot best separator for all data
    A = [ones(size(A,1),1) , A_orig(:,feats(1))];
    xmin= fast_grad_descent_logistic(A,b);
    
    hold on
    plot_poly(xmin,feats,'k')
    
    % plot result of using both features for comparison
    hold on
    A = [ones(size(A_orig,1),1) A_orig];
    x= fast_grad_descent_logistic(A,b);
    plot_poly(x,[],'g')
    set(gcf,'color','w');
    box off
    axis([0 1 0 1])

    % project data onto chosen feature space
    if feats(1) == 1
        subplot(2,1,2)
        ind = find(b == 1);
        plot(A_orig(ind,1),zeros(length(ind),1),'o','MarkerEdgeColor','b','MarkerFaceColor','b','MarkerSize',7)
        hold on
        ind = find(b == -1);
        plot(A_orig(ind,1),zeros(length(ind),1),'o','MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',7)   
        hold on
        p = -xmin(1)/xmin(2);
        plot(p,0,'o','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',9)   
        hold on
        s = -0.05:0.001:0.05;
        plot(p,s,'o','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',5)   

        axis([0 1 -0.2 0.2])
        xlabel('a_1','Fontsize',14,'FontName','cmr10')
        box off
    end
end
    
function plot_poly(x,feats,color)
    % Generate poly seperator
    s = [0:0.01:1];
    if length(x) < 3
        z = zeros(3,1);
        z(1) = x(1);
        z(feats(end) + 1) = x(2);
        ind = find(z == 0);
        z(ind) = 10^-5;
        x = -z/z(end);
    else
        x = -x/x(end);
    end
    t = x(1) + x(2)*s;
  
    % plot separator
    plot(s,t,color,'linewidth',1.25);
end

function [A,b] = load_data()
           
    data = load('simple_feat_select_data.mat');
    data = data.data;
    A = data(:,1:end - 1);
    b = data(:,end);
    
    % Generate points and plot
    subplot(2,1,1)
    ind = find(b == 1);
    plot(A(ind,1),A(ind,2),'o','MarkerEdgeColor','b','MarkerFaceColor','b','MarkerSize',7)
    hold on
    ind = find(b == -1);
    plot(A(ind,1),A(ind,2),'o','MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',7)
    
    xlabel('a_1','Fontsize',14,'FontName','cmr10')
    ylabel('a_2','Fontsize',14,'FontName','cmr10')

end

function x = fast_grad_descent_logistic(A,b)
    % Initializations 
    L = norm(A)^2;
    alpha = 4/L;
    x = randn(size(A,2),1);
    y = x;
    grad = 1;
    iter = 1;
    max_its = 2000;
    A = diag(b)*A;
    % main loop
    while norm(grad) > 10^-5 && iter <= max_its 
        % form gradient and take accelerated step
        x0 = x;
        grad = - (A'*(sigmoid(-A*y)));
        x = y - alpha*grad;
        y = x + iter/(iter+3)*(x - x0);
        iter = iter + 1;
    end

    % sigmoid function
    function y = sigmoid(z)
    y = 1./(1+exp(-z));
    end

end

function score = evaluate(A,b,x)
    % compute score of trained model on test data

    score = 0;  % initialize
    s = A*x;
    ind = find(s > 0);
    s(ind) = 1;
    ind = find(s <= 0);
    s(ind) = -1;
    t = s.*b;
    ind = find(t < 0);
    t(ind) = 0;
    score = 1 - sum(t)/numel(t);

end

end





