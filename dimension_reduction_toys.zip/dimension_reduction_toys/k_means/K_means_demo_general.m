function K_means_demo_general()
% k-means demo!

[A, c] = clustering_data_maker_general();

A = A';
c = c';
N = size(A,2);      % number of points
K = size(c,2);      % number of clusters

C = c;              % container for centroids
t = 1;              % counter
d = 1;              % container for centroid movement    
eps = 10^-6         % stopping condition

figure;
scatter(A(1,:),A(2,:),'fill','k');
axis([0 1 0 1]);
set(gcf,'color','w');
set(gca,'XTick',[]);
set(gca,'YTick',[]);
axis square
box on
hold on
colors = [0 0 1;
          1 0 0;
          0 1 0;
          1 0 1
          1 1 0
          0 1 1];

while d(end) > eps 
    
    label = [];
    for n = 1:N
        for k = 1:K
            diff(k) = norm(A(:,n) - C(2*t-1:2*t,k));
        end
          [val ind] = min(diff);
          label = [label ind];
    end
  
  for k = 1:K  
    scatter(C(2*t-1,k),C(2*t,k),80,'x','MarkerFaceColor',colors(k,:),'MarkerEdgeColor',colors(k,:))
    hold on
  end
  axis([0 1 0 1]);
  set(gcf,'color','w');
  set(gca, 'XTick', []);
  set(gca, 'YTick', []);
  axis square
  box on
    
  pause(2)
  AVG = [];
  for k = 1:K
      ind = find(label == k);
      scatter(A(1,ind),A(2,ind),'fill','MarkerFaceColor',colors(k,:),'MarkerEdgeColor',colors(k,:));
      hold on
      avg = mean(A(:,ind),2);
      AVG = [AVG avg];
  end
  C = [C ; AVG];
  d = [d norm(C(2*t-1:2*t,:)-C(2*t+1:2*t+2,:))];
  
  pause(2)
  for k = 1:K
    plot([C(2*t-1,k) C(2*t+1,k)],[C(2*t,k) C(2*t+2,k)],'LineStyle','--','color',colors(k,:))
    hold on
  end
  
  t = t+1;

end

figure;
subplot(1,2,1)
scatter(A(1,:),A(2,:),'fill','k');
axis([0 1 0 1]);
set(gcf,'color','w');
set(gca, 'XTick', []);
set(gca, 'YTick', []);
axis square
box on

subplot(1,2,2)
for k = 1:K
      ind = find(label == k);
      scatter(A(1,ind),A(2,ind),'fill','MarkerFaceColor',colors(k,:),'MarkerEdgeColor','none');
      hold on
end

axis([0 1 0 1]);
set(gcf,'color','w');
set(gca, 'XTick', []);
set(gca, 'YTick', []);
axis square
box on
        



