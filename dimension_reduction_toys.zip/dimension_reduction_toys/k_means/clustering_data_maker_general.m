function [A, c] = clustering_data_maker_general()

%%% User generated points to cluster %%%
format long
range = 1;     % input range
stop = 0;
axis([0 range 0 range])    % Set viewing axes
set(gca, 'XTick', []);
set(gca, 'YTick', []);
title('Place points')
box on

x = [];
y = [];

while stop < 1
    hold on
    [a,b]=ginput(1);
    if sum(size(a)) > 0 & (a > 0 & a < range & b > 0 & b < range) & stop == 0
        x = [x ; a];
        y = [y ; b];
        scatter(a,b,'fill','k')
    else
        stop = stop + 1;
    end  
end

A = [x,y];
x = [];
y = [];

prompt = {'Enter number of clusters:'};
answer = inputdlg(prompt);
K = str2num(answer{1});
colors = [0 0 1;
          1 0 0;
          0 1 0;
          1 0 1
          1 1 0
          0 1 1];

for k = 1:K 
    hold on
    [a,b]=ginput(1);
    x = [x ; a];
    y = [y ; b];
    scatter(a,b,'fill','MarkerFaceColor',colors(k,:))
end

c = [x, y];
pause(1)
close gcf
end