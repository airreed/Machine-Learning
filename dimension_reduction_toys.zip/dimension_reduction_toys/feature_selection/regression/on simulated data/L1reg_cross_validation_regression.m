function L1reg_cross_validation_regression()
% Here we illustrate 3-fold cross validation for regression

% Variables
deg = 10;
lams = logspace(-5,0,30);

% load data
[a,b] = load_data();

% split points into 3 equal sized sets and plot
c = split_data(b);

% do 3-fold cross-validation
cross_validate(a,b,c,lams,deg);  

function c = split_data(b)
    % split data into 3 equal sized sets
    K = length(b);
    order = randperm(K);
    c = ones(K,1);
    K = round((1/3)*K);
    c(order(K+1:2*K)) =2;
    c(order(2*K+1:end)) = 3;
end
        
function cross_validate(a,b,c,lams,deg)  
    %%% performs 3-fold cross validation

    % solve for weights and collect test errors
   
    % generate features
    A = [];
    for j = 0:deg
        A = [A  a.^j];
    end
    test_errors = [];
    for i = 1:length(lams)        
        test_resids = [];
        for j = 1:3
            A_1 = A(find(c ~= j),:);
            b_1 = b(find(c ~= j));
            A_2 = A(find(c==j),:);
            b_2 = b(find(c==j));
            x = fast_grad_descent_L1_reg_LS(A_1',b_1,lams(j));
            resid = norm(A_2*x - b_2)/numel(b_2);
            test_resids = [test_resids resid];
        end
        test_errors = [test_errors; test_resids];
    end
    test_ave = mean(test_errors');
    [val,j] = min(test_ave);
    xmin = fast_grad_descent_L1_reg_LS(A',b,lams(j));
    
    % output model
    plot_poly(xmin,'m',deg)   
    axis([0 1 -2 2])
    box on
    xlabel('a','Fontsize',14,'FontName','cmmi9')
    ylabel('b','Fontsize',14,'FontName','cmmi9')
    set(get(gca,'YLabel'),'Rotation',0)
    set(gca,'YTickLabel',[])
    set(gca,'YTick',[])
    set(gcf,'color','w');
    set(gca,'FontSize',12); 

    figure(2)
    bar(0:length(xmin)-1,xmin);
    xlabel('x-index','Fontsize',14,'FontName','cmr10')
    set(gcf,'color','w');
    box off
end
    
function plot_poly(x,color,deg)
    s = [0:0.001:1];
    t = 0;
    for k = 1:deg+1;
        t = t + x(k)*s.^(k-1);
    end
    plot(s,t,color,'LineWidth',1.25)
end

function x = fast_grad_descent_L1_reg_LS(A,b,lam)
    % Initializations 
    x = randn(size(A,1),1);    % initial point
    L = norm(A)^2;           % Lipschitz constant of perceptron
    alpha = 1/L;               % step length
    iter = 1;
    max_its = 2000;
    stopper = 1;
    y = x;
    A2 = A*A';
    b2 = A*b;
    while  stopper > 10^-5 && iter < max_its
        % form gradient and take accelerated step
        x0 = x;
        grad = A2*y - b2;
        x = y - alpha*grad;
        x(2:end) = max(abs(x(2:end)) - 2*lam*alpha,0).*sign(x(2:end));
        y = x + iter/(iter+3)*(x - x0);
        
        % update stopper/iteration count
        stopper = norm(x - x0)/norm(x0);
        iter = iter + 1;
    end
end

function [a,b] = load_data()
        
    % load points and plot
    data = load('discrete_sin_data.mat');
    data = data.c;
    a = data(:,1);
    b = data(:,2);

    % plot
    plot(a,b,'o','MarkerEdgeColor','k','MarkerFaceColor','k')
    hold on
    xlabel('a','Fontsize',14,'FontName','cmr10')
    ylabel('b','Fontsize',14,'FontName','cmr10')

end

end



