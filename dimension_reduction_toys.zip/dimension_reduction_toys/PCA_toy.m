function PCA_toy()

% This file is associated with the book (tentatively titled)
%
% "Machine Learning Done Right"
% 
% by Jeremy Watt, Reza Borhani, and Aggelos Katsaggelos


% adjacency_toy - a toy experiment that compares PCA and RPCA from
% user-inputed 2D data 

%%% User generated points %%%
format long
stop = 0;
axis([-1 1 -1 1])    % Set viewing axes
x = [];
y = [];
while stop == 0
    hold on
    [a,b]=ginput(1);
    if sum(size(a)) > 0 & (a > -1 & a < 1 & b > -1 & b < 1)
        x = [x ; a];
        y = [y ; b];
        scatter(a,b,'fill','r')
    else
        stop = 1;
    end  
end
close(gcf)
B = [x y];
n = size(B,1);
means = repmat(mean(B),n,1);
B = B - means;  % center the data
B = B';

%%% Produce PCs %%%
[U,S,V] = svd(B);
A = U*S;
A = A(:,1:2);

% Print points and pcs
subplot1(1,2,'Gap',[0.05,0.05])
subplot1(1)
for j = 1:n
    hold on
    scatter(B(1,j),B(2,j),'fill','r')
end
for i = 1:2
    hold on
    sar = quiver(0,0,A(1,i),A(2,i)); 
    set(sar, 'LineWidth', 1.5)
    set(sar,'Color','k')
end
axis([-1.25 1.25 -1.25 1.25])    % Set viewing axes
axis square
title('Data with pcs')

% Plot projected data
subplot1(2)
A = A(:,1); % Keep only the 1st pc
B_proj = A*((A'*A)\(A'*B));
for j = 1:n
    hold on
    scatter(B_proj(1,j),B_proj(2,j),'fill','r')
end
axis([-1.25 1.25 -1.25 1.25])    % Set viewing axes
axis square
title('Data projected onto 1st pc')
set(gcf,'color','w');

end
    
    








