function matrix_complete_wrapper()
prop = 0.95;

% MATRIX_COMPLETE_WRAPPER - test wrapper for producing matrix completion
% experiment.  Dimensions of matrix and rank tuneable below.
% INPUT:
% prop - proportion of matrix to remove for testing

% Generate random matrix for testing
N = 100;     % X dimension of test matrix B
M = 200;     % Y dimension of test matrix B
K = 5;
int_or_not = 0;  % Decide integer or continuous values in matrix
U = [];
V = [];
if int_or_not == 0 % Low rank integer valued matrix
    score_max = 2;
    U = randi(score_max,N,K);
    V = randi(score_max,M,K);
    B = U*V';  
else  % Low-rank uniform i.i.d. matrix
    U = rand(N,K);
    V = rand(M,K);
end

max_b = max(max(B));
min_b = min(min(B));
K = rank(B);      % rank of matrix

% Produce mask for projection
[B_corrupt, M] = disolve_matrix(B,prop);
% Add gaussian noise
sigma = 1;
B_corrupt = B_corrupt + sigma*randn(size(B_corrupt));

% Set tuning parameters and roll out
lam_ALS = 1;  % regularization coeff for penalizing Frobenius norms of A and X 
lam_dual = 10;
rho = .1;
max_its = 50;
[r c val] = find(M > 0);
omega = [r c];
om_out = find(M == 0);

[A, X] = matrix_complete_ALS(B_corrupt,K,omega,lam_ALS,max_its); 

% Output recovered matrix L and compare to original B
gaps_x = [1:M];
gaps_y = [1:N];

figure(2)
imshow(B_corrupt,[])
colormap hot
colorbar
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'CLim',[0,max_b])
title('corrupted')
set(gcf,'color','w');


figure(1)
imshow(B,[])
colormap hot
colorbar
set(gca,'XTick',gaps_x)
set(gca,'YTick',gaps_y)
set(gca,'CLim',[0,max_b])
title('original')
set(gcf,'color','w');

hold on
figure(3)
imshow(A*X,[])
colormap hot
colorbar
set(gca,'XTick',gaps_x)
set(gca,'YTick',gaps_y)
set(gca,'CLim',[0,max_b])
RMSE_mat = sqrt(norm(A*X - B,'fro')/prod(size(B)));
f = ['RMSE-ALS = ',num2str(RMSE_mat),'  rank = ', num2str(rank(A*X))];
title(f)
set(gcf,'color','w');

end

function L = matrix_complete_dual(B,om_out,lam,r,max_its)

% Initialize variables
L = randn(size(B));
Z = L;
A = randn(size(B));

% Main
for i = 1:max_its

    % Update L
    L = 1/(1+r)*(B + r*(Z - 1/r*A));
    C = Z - 1/r*A;
    L(om_out) = C(om_out);

    % Update Z
    [U,S,V] = svd(L + 1/r*A);
    Z = U*(max(abs(S) - lam/r,0).*sign(S))*V';

    % Update dual variables 
    A = A + r*(L - Z);
    
end
end
function [A, X] = matrix_complete_ALS(B,K,omega,lam,max_its)

% Initialize variables
A = randn(size(B,1),K);
X = randn(K,size(B,2));

r = omega(:,1);
c = omega(:,2);
% Main
for i = 1:max_its

    % Update X
    for k = 1:size(X,2)
        ind = r(find(c==k));
        P = zeros(size(X,1));
        q = zeros(size(X,1),1);
        for m = 1:length(ind)
            P = P + A(ind(m),:)'*A(ind(m),:); 
            q = q + B(ind(m),k)*(A(ind(m),:)');
        end
        
        X(:,k) = pinv(P + lam*eye(size(X,1)))*q; 
    end

    % Update A
    for k = 1:size(A,1)
        ind = c(find(r==k));
        P = zeros(size(A,2));
        q = zeros(1,size(A,2));
        for m = 1:length(ind)
            P = P + X(:,ind(m))*(X(:,ind(m))'); 
            q = q + B(k,ind(m))*(X(:,ind(m))');
        end
        
        A(k,:) = q*pinv(P + lam*eye(size(A,2))); 
    end

    
end

end
function [corrupt_img, Mask] = disolve_matrix(I,prop)

% Remove a proportion of entries given by prop, from 0 to 1
[sample,idx] = datasample(reshape(I,prod(size(I)),1),round(prop*prod(size(I))),'Replace',false);
I(idx) = 0;
corrupt_img = I;

% Mask for the entries we still have, used in the optimization
Mask = ones(size(I));
Mask(idx) = 0;


end