function cross_validation_regression_feat_select()
% Here is illustrated feature selection with 3-fold cross validation
% using logistic regression and polyonimal features
% clear all

% poly degs to look over
num_feats = 1;

% load data etc.,
[A,b] = load_data();

% split points into 3 equal sized sets and plot
c = split_data(A,b);

% do 3-fold cross-validation
cross_validate(A,b,c,num_feats);  

function c = split_data(a,b)
    % split data into 3 equal sized sets
    K = length(b);
    order = randperm(K);
    c = ones(K,1);
    K = round((1/3)*K);
    c(order(K+1:2*K)) =2;
    c(order(2*K+1:end)) = 3;
end
        
function cross_validate(A_orig,b,c,desired_num)  
    %%% performs 3-fold cross validation

    % solve for weights and collect test errors
    feats = []; 
    while length(feats) < desired_num
        test_errors = [];
        for i = 1:2
            % generate features
            A = [];
            if i == 1
                A = [ones(size(A,1),1), A_orig(:,1)];
            else
                A = [ones(size(A,1),1), A_orig(:,2)];
            end

            test_resids = [];
            for j = 1:3
                A_1 = A(find(c ~= j),:);
                b_1 = b(find(c ~= j));
                A_2 = A(find(c==j),:);
                b_2 = b(find(c==j));

                % solve LS 
                x = linsolve(A_1,b_1);

                % compute test error
                resid = norm(A_2*x - b_2)/numel(b_2);
                test_resids = [test_resids resid]; 
            end
            test_errors = [test_errors; test_resids];
        end
        % choose next feature based on minimum ave test error
        test_ave = mean(test_errors');
        [val,j] = min(test_ave);
        
        % add best new feature to feature set, remove from check list
        feats = [feats, j];
    end

    % plot best separator for all data
    A = [ones(size(A,1),1) , A_orig(:,feats(1))];
    xmin = linsolve(A,b);
    
    subplot(1,2,feats(1))
    plot_poly(xmin,feats,'r',min(A_orig(:,feats(1))),max(A_orig(:,feats(1))))
    set(gcf,'color','w');
    box off

end
    
function plot_poly(x,feats,color,amin,amax)
    % Generate poly seperator
    s = amin:0.1:amax+1;
    t = x(1) + x(2)*s;
    hold on
    plot(s,t,color,'linewidth',1.5);
end

% loads data
function [A,b] = load_data()

    % load points and plot
    data = load('debt_data.mat');
    data = data.data;
    A = data(:,1:2);
    b = data(:,3);
    
    % plot
    plot3(A(:,1),A(:,2),b,'o','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',7)
    xlabel('year','Fontsize',14,'FontName','cmr10')
    ylabel('Chiquita sales (in hundreds of millions)','Fontsize',14,'FontName','cmr10')
    zlabel('student debt (in trillions)','Fontsize',14,'FontName','cmr10')

    hold on
    set(gcf,'color','w');
    set(gca,'FontSize',12); 
    box on
    
    figure(2)
    subplot(1,2,1)
    plot(A(:,1),b,'o','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',7)
    xlabel('year','Fontsize',14,'FontName','cmr10')
    ylabel('student debt (in trillions)','Fontsize',14,'FontName','cmr10')
    box off
    
    subplot(1,2,2)
    plot(A(:,2),b,'o','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',7)
    xlabel('Chiquita sales (in hundreds of millions)','Fontsize',14,'FontName','cmr10')
    ylabel('student debt (in trillions)','Fontsize',14,'FontName','cmr10')
    box off
end
end





